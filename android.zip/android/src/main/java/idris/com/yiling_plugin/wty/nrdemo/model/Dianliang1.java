package idris.com.yiling_plugin.wty.nrdemo.model;

/**
 * Created by Administrator on 2018/8/20.
 */

public class Dianliang1 {
    public int y;
    public int mm;
    public int d;
    public int h;
    public int m;
    public int s;
}
