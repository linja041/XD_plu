package idris.com.yiling_plugin.wty.nrdemo;

public class EcgWaveData {

    int type;

    float value;

    public EcgWaveData() {
    }

    public EcgWaveData(int type, float value) {
        this.type = type;
        this.value = value;
    }
}
