package idris.com.yiling_plugin.wty.nrdemo.model;

/**
 * Created by Benefm on 2017/6/15 0015.
 */

public class DeviceScannState {
    public int scannState=1;
    public String mac;
}

