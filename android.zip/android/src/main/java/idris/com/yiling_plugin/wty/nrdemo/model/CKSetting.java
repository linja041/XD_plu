package idris.com.yiling_plugin.wty.nrdemo.model;

/**
 * Created by Administrator on 2019/1/3.
 */

public class CKSetting {
    public String fileName;
    public String name;
    public byte sex;
    public byte age;
    public byte mode;
}
