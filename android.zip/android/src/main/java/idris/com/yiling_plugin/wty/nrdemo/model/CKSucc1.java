package idris.com.yiling_plugin.wty.nrdemo.model;

/**
 * Created by Administrator on 2018/8/20.
 */

public class CKSucc1 {
    public int size;
}
