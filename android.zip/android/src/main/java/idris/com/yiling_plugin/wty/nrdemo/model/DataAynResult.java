package idris.com.yiling_plugin.wty.nrdemo.model;

/**
 * Created by Administrator on 2018/8/23.
 */

public class DataAynResult {
    public double[] HvrTime;
    public double[] HrvFre;
}
