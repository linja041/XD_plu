package idris.com.yiling_plugin.wty.nrdemo.model;

/**
 * Created by Benefm on 2017/6/15 0015.
 */

public class DeviceConnState {
    public int connState=0;
    public int deviceType=0;//0,1,2ems
    public String mac;
}

