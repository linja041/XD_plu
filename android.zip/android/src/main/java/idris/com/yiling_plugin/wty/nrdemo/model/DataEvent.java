package idris.com.yiling_plugin.wty.nrdemo.model;

/**
 * Created by Administrator on 2018/8/20.
 */

public class DataEvent {
    public int[] data1=new int[10];
    public int[] data2=new int[10];
    public int[] data11=new int[10];
    public int[] data12=new int[10];
    public int[] data13=new int[10];
    public int[] data14=new int[10];
    public int[] data15=new int[10];
    public int[] data16=new int[10];
    public int hr;
    public int xy;
    public int ml;
    public int xyWave;
    public int dy;
    public boolean isTuo;
    public boolean isNormal;
    public int isCharging;
}
