package idris.com.yiling_plugin.wty.nrdemo.model;

/**
 * Created by Benefm on 2017/6/15 0015.
 */

public class DeviceSwitchState {
  public boolean state;
}

